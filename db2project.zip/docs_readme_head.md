# DB2 Projekt - Eshop



## Definiton:

[https://db.dai.fmph.uniba.sk/teaching/db2/projekt/](https://db.dai.fmph.uniba.sk/teaching/db2/projekt/)

[https://docs.google.com/document/d/12sy75jUickbnZCY0HU3kC7AHjLCxAdfOPmqy-dRTYis/edit#](https://docs.google.com/document/d/12sy75jUickbnZCY0HU3kC7AHjLCxAdfOPmqy-dRTYis/edit#)


## To run:
```
go run main.go
```


## Requirements

Golang 1.18 (because of generics)